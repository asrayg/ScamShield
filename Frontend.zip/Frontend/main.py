import sys
import requests
import numpy as np
from pydub import AudioSegment
from pydub.silence import detect_nonsilent
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QPushButton, QTextEdit, QLabel
from PyQt5.QtCore import QThread, pyqtSignal
import speech_recognition as sr
from dotenv import load_dotenv
import os

load_dotenv()

BACKEND_URL = os.getenv('BACKEND_URL')

class RingingDetectionThread(QThread):
    ringing_detected = pyqtSignal(str, str)  # signal to update UI

    def __init__(self):
        super().__init__()
        self.recognizer = sr.Recognizer()
        self.microphone = sr.Microphone()

    def detect_ringing(self, audio_segment):
        non_silent_ranges = detect_nonsilent(audio_segment, min_silence_len=1000, silence_thresh=-32)
        return len(non_silent_ranges) > 0

    def analyze_audio(self):
        with self.microphone as source:
            self.recognizer.adjust_for_ambient_noise(source)
            audio = self.recognizer.listen(source)
            audio_data = audio.get_wav_data()
            audio_segment = AudioSegment(audio_data)

            if self.detect_ringing(audio_segment):
                try:
                    text = self.recognizer.recognize_google(audio)
                    self.send_to_backend(text)
                except sr.UnknownValueError:
                    self.ringing_detected.emit("Error", "Google Speech Recognition could not understand audio")
                except sr.RequestError as e:
                    self.ringing_detected.emit("Error", f"Could not request results from Google Speech Recognition service; {e}")

    def send_to_backend(self, text):
        try:
            response = requests.post(f'{BACKEND_URL}/api/analyze_transcription/', data={'text': text})
            if response.status_code == 200:
                result = response.json()
                self.ringing_detected.emit(result.get('result', 'No result'), result.get('transcription', ''))
            else:
                self.ringing_detected.emit("Error", "Error from backend")
        except Exception as e:
            self.ringing_detected.emit("Error", str(e))

    def run(self):
        while True:
            self.analyze_audio()

class ScamShieldApp(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()
        self.thread = RingingDetectionThread()
        self.thread.ringing_detected.connect(self.update_ui)
    
    def initUI(self):
        self.setWindowTitle('ScamShield')
        
        layout = QVBoxLayout()

        self.status_label = QLabel('Status: Waiting for call...', self)
        layout.addWidget(self.status_label)
        
        self.transcription_box = QTextEdit(self)
        self.transcription_box.setReadOnly(True)
        layout.addWidget(self.transcription_box)
        
        self.result_label = QLabel('Scam Detection Result: ', self)
        layout.addWidget(self.result_label)
        
        self.start_button = QPushButton('Start Listening', self)
        self.start_button.clicked.connect(self.start_analysis)
        layout.addWidget(self.start_button)

        self.setLayout(layout)
        
    def start_analysis(self):
        self.status_label.setText('Status: Listening...')
        self.thread.start()

    def update_ui(self, result, text):
        self.transcription_box.setText(text)
        self.result_label.setText(f"Scam Detection Result: {result}")
        self.status_label.setText('Status: Call Analyzed')

if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = ScamShieldApp()
    ex.show()
    sys.exit(app.exec_())
